package com.pq.mapper;

public class BiosisPreviewsProcessMapper extends GenericProcessMapper {

}
