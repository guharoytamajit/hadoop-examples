package com.pq.bean;

public class CfInfo {

	private String fileHead;
	private String fileTail;
	private String recordHead;
	private String recordTail;
	private String sourceFileName;
	private String orgZipFile;
	
	public String getFileHead() {
		return fileHead;
	}
	public void setFileHead(String fileHead) {
		this.fileHead = fileHead;
	}
	public String getFileTail() {
		return fileTail;
	}
	public void setFileTail(String fileTail) {
		this.fileTail = fileTail;
	}
	public String getRecordHead() {
		return recordHead;
	}
	public void setRecordHead(String recordHead) {
		this.recordHead = recordHead;
	}
	public String getRecordTail() {
		return recordTail;
	}
	public void setRecordTail(String recordTail) {
		this.recordTail = recordTail;
	}
	public String getSourceFileName() {
		return sourceFileName;
	}
	public void setSourceFileName(String sourceFileName) {
		this.sourceFileName = sourceFileName;
	}
	public String getOrgZipFile() {
		return orgZipFile;
	}
	public void setOrgZipFile(String orgZipFile) {
		this.orgZipFile = orgZipFile;
	}
	
}
