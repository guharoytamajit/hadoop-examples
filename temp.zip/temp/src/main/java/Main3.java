import java.util.regex.Pattern;

import com.fasterxml.jackson.core.JsonParser;

public class Main3 {
public static void main(String[] args) {
	System.out.println(Pattern.compile("^prevd\\d+.(zip|ZIP)$").matcher("prevd123.zip").matches());
System.out.println("wsxw\\d");
}
}
